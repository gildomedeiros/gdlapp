/*
  GDL client_lora_v2_1 - LILYGO LoRa / Wi-Fi bridge - 2026-09-16
  Pair with server_lora_v2. Based on working loraclililygo_wifi.ino.

  ARDUINO IDE SETUP - THE WORKING COMBINATION
  File > Preferences > Additional Boards Manager URLs:
  https://dl.espressif.com/dl/package_esp32_index.json
  https://github.com/HelTecAutomation/CubeCell-Arduino/releases/download/V1.5.0/package_CubeCell_index.json
  Boards Manager: esp32 by Espressif Systems, EXACTLY 2.0.17.
  Tools > Board > esp32 > TTGO LoRa32-OLED.
  Tools > Board Revision > TTGO LoRa32 V1 (No TFCard).
  Other board settings: defaults; select the LILYGO USB COM port.
  Serial Monitor: 115200 baud.
  IMPORTANT: 2.0.17 + the V1 selection restored readable 115200 serial and
  working Wi-Fi in the original tests. ESP32 3.3.11 was the troublesome setup;
  do not upgrade the core while reproducing the known working configuration.
  Library Manager (exact locally installed versions):
    LoRa by Sandeep Mistry, 0.8.0 -> LoRa.h
    ESP8266 and ESP32 OLED driver for SSD1306 displays
      by ThingPulse / Fabrice Weinberg, 4.6.2 -> SSD1306Wire.h
  SPI, Wire, WiFi, WiFiUdp come with the ESP32 core.
  Do NOT use ESP8266WiFi.h, HT_SSD1306Wire.h, or substitute Adafruit_SSD1306.
  No ESP32Ping, HTTPClient or Heltec ESP32 library is required.
  Existing sketchbook on this PC: C:\Users\gildo\Documents\Arduino\hw\CubeCell
  Each sketch must be inside a folder matching its .ino name.

  Pins: SX1276 SCK5 MISO19 MOSI27 CS18 RST14 DIO0=26.
  OLED: SDA4 SCL15 RST16, address0x3C. Attach the LoRa antenna before TX.
  LoRa: 917 MHz, SF7, BW125 kHz, CR4/5, preamble8, CRC, sync0x12.

  PHONE / CAM3: connect to GDL_LORA (password gdl12345), AP 192.168.4.1,
  Wi-Fi channel6. Bind UDP5005, send HELLO to 192.168.4.1:5006.
  Reply: GDL_LILYGO_READY. Latest HELLO sender receives the stream.
  GPS output: RX,GPS,SEQ,MILLIS,LAT,LON,SATS,HDOP,RSSI,SNR,MISSED
  No-fix: RAW,NOFIX,SEQ,MILLIS,SATS,CHARS,RSSI,SNR,MISSED
  MISSED is the gap for that packet; OLED Lost is cumulative.
  Server controls 2 Hz. Client forwards each accepted GPS/NOFIX packet.
  Every sequence divisible by10 schedules HB,SEQ after25 ms, independently
  of Wi-Fi/phone status. Async radio TX keeps UDP serviced; RX resumes on TX
  completion. Server opens a 200 ms listening window after that same packet.
  No retries within the window; next opportunity is ~5 seconds later.
  With GPS blue on the server, heartbeat briefly overrides it GREEN for100 ms.
  Original loraserver.ino has unsequenced NOFIX and is NOT compatible.

  Sources: installed esp32 2.0.17 boards.txt; local library.properties;
  https://github.com/sandeepmistry/arduino-LoRa/blob/master/API.md
  https://github.com/ThingPulse/esp8266-oled-ssd1306
  V2 must be tested on the two boards; original bridge was hardware-tested.
*/
#include <SPI.h>
#include <LoRa.h>
#include <Wire.h>
#include <SSD1306Wire.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <stdlib.h>
#include <errno.h>

SSD1306Wire display(0x3C, 4, 15);
WiFiUDP udp;
IPAddress phoneIP;
bool phoneKnown = false, haveSequence = false;
uint32_t lastSequence = 0, lastSenderMillis = 0, lostPackets = 0;
bool hbPending = false, hbTransmitting = false;
volatile bool hbTxFinished = false;
String deferredOutput;
uint32_t hbSequence = 0, hbReceivedAt = 0, hbTxAt = 0;
const uint32_t HB_DELAY_MS = 25, HB_LATEST_START_MS = 80;

void IRAM_ATTR onHeartbeatTxDone() {
  hbTxFinished = true; // Only a flag in the ISR; restore RX in loop().
}

bool parseUnsigned(const char *s, uint32_t &value) {
  if (!s || !*s) return false;
  for (const char *p = s; *p; ++p) if (*p < '0' || *p > '9') return false;
  errno = 0; char *end;
  unsigned long v = strtoul(s, &end, 10);
  if (errno == ERANGE || *end) return false;
  value = v; return true;
}

void sendToPhone(const String &message) {
  if (!phoneKnown) return;
  udp.beginPacket(phoneIP, 5005);
  udp.print(message); udp.print('\n'); udp.endPacket();
}

void checkPhoneHello() {
  int n = udp.parsePacket();
  if (n <= 0) return;
  char buffer[80];
  int length = udp.read(buffer, sizeof(buffer) - 1);
  if (length <= 0 || n >= int(sizeof(buffer))) return;
  buffer[length] = 0;
  String message(buffer); message.trim();
  if (message != "HELLO") return;
  phoneIP = udp.remoteIP(); phoneKnown = true;
  Serial.print("PHONE FOUND: "); Serial.println(phoneIP);
  sendToPhone("GDL_LILYGO_READY");
}

void serviceHeartbeat() {
  uint32_t now = millis();
  if (hbTransmitting) {
    if (hbTxFinished) {
      LoRa.onTxDone(nullptr);
      hbTransmitting = false; LoRa.receive();
    } else if (uint32_t(now - hbTxAt) > 300) {
      LoRa.onTxDone(nullptr);
      LoRa.idle(); hbTransmitting = false; LoRa.receive();
      Serial.println("HEARTBEAT TX TIMEOUT");
    }
  }
  if (!hbPending || hbTransmitting) return;
  uint32_t age = now - hbReceivedAt;
  if (age > HB_LATEST_START_MS) {
    hbPending = false; return; // Never send a late HB over the next GPS TX.
  }
  if (age < HB_DELAY_MS) return;
  if (!LoRa.beginPacket()) return;
  LoRa.print("HB,"); LoRa.print(hbSequence);
  hbTxFinished = false;
  // Attach ONLY during TX. LoRa 0.8.0's DIO0 ISR also clears RX flags;
  // leaving it attached would consume packets before parsePacket() sees them.
  LoRa.onTxDone(onHeartbeatTxDone);
  if (LoRa.endPacket(true)) {
    hbPending = false; hbTransmitting = true; hbTxAt = now;
    Serial.print("HEARTBEAT SENT #"); Serial.println(hbSequence);
  } else {
    LoRa.onTxDone(nullptr);
    hbPending = false; LoRa.receive();
  }
}

void processPacket(char *packet, int rssi, float snr, uint32_t receivedAt) {
  size_t length = strlen(packet);
  if (!length || packet[0] == ',' || packet[length - 1] == ',' || strstr(packet, ",,")) return;
  char working[160]; strncpy(working, packet, sizeof(working));
  working[sizeof(working) - 1] = 0;
  char *fields[8], *save = nullptr;
  unsigned count = 0;
  for (char *p = strtok_r(working, ",", &save); p && count < 8;
       p = strtok_r(nullptr, ",", &save)) fields[count++] = p;
  if (count != 7 && count != 5) return;
  bool gps = strcmp(fields[0], "GPS") == 0 && count == 7;
  bool nofix = strcmp(fields[0], "NOFIX") == 0 && count == 5;
  if (!gps && !nofix) return;
  uint32_t sequence, senderMillis;
  if (!parseUnsigned(fields[1], sequence) || !parseUnsigned(fields[2], senderMillis)) return;

  uint32_t missed = 0;
  if (haveSequence) {
    uint32_t advance = sequence - lastSequence;
    // Signed modular comparison handles rollover; lower seq + lower uptime
    // is a reboot of the single paired sender. Duplicates/stale packets drop.
    bool restart = sequence < lastSequence && senderMillis < lastSenderMillis &&
                   int32_t(senderMillis - lastSenderMillis) < 0;
    if (!restart) {
      if (advance == 0 || advance >= 0x80000000UL) return;
      missed = advance - 1;
    } else {
      Serial.println("SERVER RESTART: sequence baseline reset");
    }
  }
  lastSequence = sequence; lastSenderMillis = senderMillis; haveSequence = true;
  lostPackets += missed;
  if (sequence % 10 == 0) {
    hbPending = true; hbSequence = sequence; hbReceivedAt = receivedAt;
  }
  String output = String(gps ? "RX," : "RAW,") + packet + "," +
                  String(rssi) + "," + String(snr, 1) + "," + String(missed);
  // OLED transfers can consume much of the turnaround margin. Defer display
  // and UDP on HB packets until the radio has started the reply.
  if (hbPending) { deferredOutput = output; return; }
  Serial.println(output); sendToPhone(output);
  display.clear();
  display.drawString(0, 0, "RX #" + String(sequence));
  display.drawString(0, 13, gps ? "LAT " + String(fields[3]) : "NO GPS FIX");
  display.drawString(0, 26, gps ? "LON " + String(fields[4]) : "Waiting for fix");
  display.drawString(0, 39, "R " + String(rssi) + " S " + String(snr, 1));
  display.drawString(0, 52, "Lost:" + String(lostPackets) + (phoneKnown ? " WIFI" : ""));
  display.display();
}

void setup() {
  Serial.begin(115200); delay(500);
  pinMode(16, OUTPUT); digitalWrite(16, LOW); delay(20); digitalWrite(16, HIGH);
  Wire.begin(4, 15); display.init();
  WiFi.mode(WIFI_AP); delay(200);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  bool apOK = WiFi.softAP("GDL_LORA", "gdl12345", 6, false, 4);
  Serial.print("WiFi AP: "); Serial.println(apOK ? "OK" : "FAILED");
  Serial.print("AP IP: "); Serial.println(WiFi.softAPIP());
  if (!udp.begin(5006)) Serial.println("UDP START FAILED");
  SPI.begin(5, 19, 27, 18); LoRa.setPins(18, 14, 26);
  if (!LoRa.begin(917000000)) {
    Serial.println("LORA INIT FAILED");
    display.clear(); display.drawString(0, 0, "LORA ERROR"); display.display();
    while (true) delay(1000);
  }
  LoRa.setSignalBandwidth(125000); LoRa.setSpreadingFactor(7);
  LoRa.setCodingRate4(5); LoRa.setPreambleLength(8); LoRa.enableCrc();
  LoRa.disableInvertIQ(); LoRa.setSyncWord(0x12); LoRa.setTxPower(14);
  LoRa.receive();
  Serial.println("GDL CLIENT V2 READY: LoRa 917 MHz, AP GDL_LORA channel6");
  Serial.println("Control UDP: 5006; Phone UDP: 5005; HB every 10 server packets");
  display.clear(); display.drawString(0, 0, "GDL CLIENT V2");
  display.drawString(0, 16, "AP: GDL_LORA");
  display.drawString(0, 32, "192.168.4.1");
  display.drawString(0, 48, "WAIT PHONE HELLO"); display.display();
}

void loop() {
  serviceHeartbeat();
  if (hbPending) return; // At most25 ms; keep turnaround free of UDP/OLED work.
  if (deferredOutput.length()) {
    Serial.println(deferredOutput); sendToPhone(deferredOutput); deferredOutput = "";
  }
  checkPhoneHello(); serviceHeartbeat();
  if (hbTransmitting) return;
  int size = LoRa.parsePacket();
  if (!size) return;
  uint32_t receivedAt = millis();
  char packet[160]; unsigned n = 0;
  while (LoRa.available()) {
    int c = LoRa.read();
    if (n < sizeof(packet) - 1) packet[n++] = char(c);
  }
  packet[n] = 0;
  int rssi = LoRa.packetRssi(); float snr = LoRa.packetSnr();
  LoRa.receive();
  if (size >= int(sizeof(packet))) return;
  processPacket(packet, rssi, snr, receivedAt);
}
