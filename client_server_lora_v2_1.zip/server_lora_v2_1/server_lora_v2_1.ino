/*
  GDL server_lora_v2 - CubeCell GPS sender - 2026-09-16
  Pair with client_lora_v2. Based on the working loraserver_2.ino.

  ARDUINO IDE SETUP (keep this with the source)
  File > Preferences > Additional Boards Manager URLs: add BOTH lines:
  https://github.com/HelTecAutomation/CubeCell-Arduino/releases/download/V1.5.0/package_CubeCell_index.json
  https://dl.espressif.com/dl/package_esp32_index.json
  Boards Manager: CubeCell Development Framework by Heltec, version 1.5.0
  Tools > Board: CubeCell-GPS (HTCC-AB02S), NOT an ESP32 Heltec board.
  Tools > LORAWAN_RGB: DEACTIVE (this sketch drives the RGB LED itself).
  Other board options: defaults. This is raw LoRa: RF frequency is set below,
  not by the LoRaWAN region menu. Select the CubeCell USB COM port.
  Serial Monitor: 115200 baud. Attach the LoRa antenna before powering TX.
  Libraries: use the CubeCell 1.5.0 BUNDLED LoRaWan_APP, OnBoardGPS,
  DISPLAY (HT_SSD1306Wire.h), and RGB (CubeCell_NeoPixel.h).
  Do not substitute the ESP32 LoRa.h or ThingPulse display library here.
  No extra Library Manager downloads are required for this server.

  GPS: Air530Class, as in the working sketch. Air530Z is a different command
  protocol; do not merely rename the class. This version targets AIR530.
  PGKC101 sets 500 ms output; GGA + RMC keep 9600-baud serial traffic small.
  The startup rate request is NOT proof of acceptance: GPS_RATE diagnostics
  report observed distinct GPS UTC times. Outdoors, expect ~20 / 10 seconds
  and a last UTC step of 500 ms. At ~10 / 10 seconds the GPS is still at 1 Hz.
  Packet MILLIS is sender uptime, NOT a GPS fix timestamp.

  RADIO: 917 MHz, SF7, BW125 kHz, CR4/5, preamble8, CRC, private sync0x12.
  GPS,SEQ,MILLIS,LAT,LON,SATS,HDOP or NOFIX,SEQ,MILLIS,SATS,CHARS.
  Sequence increments on EVERY TX attempt, even NOFIX; interval 500 ms.
  After every tenth TX, listen for 200 ms for HB,<that same sequence>.
  Client replies 25 ms after receiving that packet (~one HB / 5 seconds).
  A missed packet/heartbeat is retried at the next tenth packet; no blocking.
  RGB: BLUE = recent valid GPS location; GREEN for 100 ms on valid heartbeat,
  then restore BLUE/off. The separate fixed-colour GPS/PPS hardware LED is
  not recoloured or driven by this sketch. RGB colours are mutually exclusive.
  Heartbeat confirms LoRa reception, NOT phone/CAM3 connectivity.

  Sources:
  https://docs.heltec.org/en/node/asr650x/asr650x_general_docs/quick_start/cubecell-use-arduino-board-manager.html
  https://files.seeedstudio.com/wiki/Grove-GPS_Air_530/Air530_GPS_User_Booklet.V1.7.pdf
  Board pin and driver APIs checked against locally installed CubeCell 1.5.0.
  V2 needs an on-device test; the earlier 1 Hz sketches were hardware-tested.
*/
#include "Arduino.h"
#include "LoRaWan_APP.h"
#include "GPS_Air530.h"
#include "HT_SSD1306Wire.h"
#include "CubeCell_NeoPixel.h"

extern SSD1306Wire display;
Air530Class GPS;
CubeCell_NeoPixel statusLed(1, RGB, NEO_GRB + NEO_KHZ800);
static RadioEvents_t radioEvents;
const uint32_t SEND_MS = 500, RX_WINDOW_MS = 200, FLASH_MS = 100;
const uint32_t GPS_MAX_AGE_MS = 1200;
uint32_t sequenceNumber = 0, lastSend = 0, rxStarted = 0, txStarted = 0;
uint32_t flashStarted = 0, lastColour = 0xFFFFFFFF;
bool txBusy = false, rxWindow = false, flashing = false;
char txpacket[120];
uint32_t lastUtc = 0, utcSamples = 0, utcStep = 0, rateReportAt = 0;
bool haveUtc = false;

bool freshFix() {
  return GPS.location.isValid() && GPS.location.age() < GPS_MAX_AGE_MS &&
         GPS.satellites.isValid() && GPS.satellites.value() > 0 &&
         GPS.satellites.age() < GPS_MAX_AGE_MS;
}

void updateLed() {
  if (flashing && uint32_t(millis() - flashStarted) >= FLASH_MS) flashing = false;
  uint32_t colour = flashing ? 0x002000 : (freshFix() ? 0x000020 : 0);
  if (colour != lastColour) {
    statusLed.setPixelColor(0, colour);
    statusLed.show();
    lastColour = colour;
  }
}

void closeRx() {
  Radio.Sleep();
  rxWindow = false;
}

void onTxDone() {
  txBusy = false;
  if (sequenceNumber % 10 == 0) {
    rxWindow = true;
    rxStarted = millis();
    Radio.Rx(RX_WINDOW_MS);
  } else {
    Radio.Sleep();
  }
}

void onTxTimeout() {
  txBusy = false;
  closeRx();
  Serial.println("TX TIMEOUT");
}

void onRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr) {
  char expected[32];
  snprintf(expected, sizeof(expected), "HB,%lu", (unsigned long)sequenceNumber);
  bool accepted = rxWindow && size == strlen(expected) &&
                  memcmp(payload, expected, size) == 0;
  closeRx();
  if (accepted) {
    flashing = true;
    flashStarted = millis();
    Serial.print("HEARTBEAT OK #");
    Serial.println(sequenceNumber);
  }
}

// Air530 sendcmd expects the complete sentence including checksum and CR/LF.
void gpsCommand(const char *body) {
  uint8_t checksum = 0;
  for (const char *p = body; *p; ++p) checksum ^= uint8_t(*p);
  char command[100];
  snprintf(command, sizeof(command), "$%s*%02X\r\n", body, checksum);
  GPS.sendcmd(String(command));
}

void feedGps() {
  while (GPS.available()) {
    GPS.encode(GPS.read());
    if (GPS.time.isUpdated() && GPS.time.isValid()) {
      uint32_t utc = (GPS.time.hour() * 3600UL + GPS.time.minute() * 60UL +
                      GPS.time.second()) * 1000UL + GPS.time.centisecond() * 10UL;
      if (!haveUtc || utc != lastUtc) {
        if (haveUtc) utcStep = (utc + 86400000UL - lastUtc) % 86400000UL;
        lastUtc = utc;
        haveUtc = true;
        ++utcSamples;
      }
    }
  }
  if (uint32_t(millis() - rateReportAt) >= 10000) {
    Serial.print("GPS_RATE UTC samples / elapsed ms: ");
    Serial.print(utcSamples); Serial.print(" / ");
    Serial.print(uint32_t(millis() - rateReportAt));
    Serial.print("; last UTC step ms: "); Serial.println(utcStep);
    rateReportAt = millis(); utcSamples = 0;
  }
}

void showStatus(bool fix) {
  display.clear();
  display.drawString(0, 0, "TX #" + String(sequenceNumber) + " 2Hz");
  if (fix) {
    display.drawString(0, 16, "LAT " + String(GPS.location.lat(), 5));
    display.drawString(0, 32, "LON " + String(GPS.location.lng(), 5));
  } else {
    display.drawString(0, 16, "NO GPS FIX");
    display.drawString(0, 32, "Chars " + String(GPS.charsProcessed()));
  }
  display.drawString(0, 48, "S:" + String(GPS.satellites.value()) +
                     " H:" + String(GPS.hdop.hdop(), 1));
  display.display();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  pinMode(Vext, OUTPUT); digitalWrite(Vext, LOW); delay(100);
  display.init();
  display.clear(); display.drawString(0, 0, "GDL SERVER V2");
  display.drawString(0, 20, "GPS starting..."); display.display();
  statusLed.begin(); statusLed.clear(); statusLed.show();
  GPS.begin(9600);
  GPS.setNMEA(NMEA_GGA | NMEA_RMC);
  gpsCommand("PGKC101,500");
  Serial.println("Requested AIR530 2 Hz; check GPS_RATE UTC diagnostics.");

  radioEvents.TxDone = onTxDone; radioEvents.TxTimeout = onTxTimeout;
  radioEvents.RxDone = onRxDone; radioEvents.RxTimeout = closeRx;
  radioEvents.RxError = closeRx;
  Radio.Init(&radioEvents);
  Radio.SetChannel(917000000);
  Radio.SetPublicNetwork(false);
  Radio.SetTxConfig(MODEM_LORA, 14, 0, 0, 7, 1, 8, false, true, 0, 0, false, 1000);
  Radio.SetRxConfig(MODEM_LORA, 0, 7, 1, 0, 8, 0, false, 0, true, 0, 0, false, true);
  Radio.Sleep();
  lastSend = millis(); rateReportAt = millis();
  Serial.println("GDL SERVER V2 READY: 917 MHz, 500 ms TX, HB every 10 packets");
}

void loop() {
  feedGps();
  Radio.IrqProcess();
  uint32_t now = millis();
  if (rxWindow && uint32_t(now - rxStarted) >= RX_WINDOW_MS) closeRx();
  if (txBusy && uint32_t(now - txStarted) >= 1500) onTxTimeout();
  updateLed();
  if (txBusy || rxWindow || uint32_t(now - lastSend) < SEND_MS) return;
  lastSend = now;
  ++sequenceNumber;
  bool fix = freshFix();
  String message;
  if (fix) {
    message = "GPS," + String(sequenceNumber) + "," + String(now) + "," +
      String(GPS.location.lat(), 5) + "," + String(GPS.location.lng(), 5) + "," +
      String(GPS.satellites.value()) + "," + String(GPS.hdop.hdop(), 1);
  } else {
    message = "NOFIX," + String(sequenceNumber) + "," + String(now) + "," +
      String(GPS.satellites.value()) + "," + String(GPS.charsProcessed());
  }
  message.toCharArray(txpacket, sizeof(txpacket));
  txBusy = true; txStarted = millis();
  Radio.Send((uint8_t *)txpacket, strlen(txpacket));
  Serial.print("Sending: "); Serial.println(txpacket);
  showStatus(fix);
}
